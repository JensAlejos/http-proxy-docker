/*$(function() {
	 $('#acceptEdiParties').click(function(){
		 alert("IN EDI PARTIES ACCEPT");
		 var status = document.getElementById('isAcceptHddn').value;
				 alert("isStatus" +status );
		//var  buttonAction =  validateOnAcceptUndoAcceptAction("acceptCommoditBtn");
			// var queryString = $('#ediCommodityDetailForm').formSerialize();
			 if(buttonAction == true){
				 alert("buttonAction"+buttonAction);
				 validateOnAcceptUndoAcceptAction(buttonAction);
			$.ajax({
				 type:"POST",
				 url:_context+"/edi/commodity/approvedDataForEdiCommodity",
				 data :queryString,
				success: function(responseText){
					alert("you are in function");
					showSuccessAcceptMessage();
					
				}	        
			 });
			 }
		 });
});
	 


*/
