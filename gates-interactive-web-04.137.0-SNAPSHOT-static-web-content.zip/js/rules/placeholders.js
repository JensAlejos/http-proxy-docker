var placeholderDescriptions = {
    "$!booking.bookingNumber": "This is the Booking number",
    "$!booking.actionUser": "This is the GATES user id that is performing the action.",
    "$!booking.actionDate": "This is the System Date when the action is performed."
};